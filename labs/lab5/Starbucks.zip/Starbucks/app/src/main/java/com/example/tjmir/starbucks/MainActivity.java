package com.example.tjmir.starbucks;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void findDrink(View view) {
        //edit text
        EditText name = (EditText) findViewById(R.id.editText);
        String nameValue = name.getText().toString();

        //Toggle Button
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        boolean temperature = toggle.isChecked();

        //Toggle Button2
        ToggleButton toggle3 = (ToggleButton) findViewById(R.id.toggleButton3);
        boolean answer = toggle3.isChecked();

        //Spinner
        Spinner beverage = (Spinner) findViewById(R.id.spinner);
        String beverageType = String.valueOf(beverage.getSelectedItem());

        //radio buttons
        RadioGroup season = (RadioGroup) findViewById(R.id.radioGroup);
        int season_id = season.getCheckedRadioButtonId();

        //check boxes
        CheckBox vanillaCheckBox = (CheckBox) findViewById(R.id.checkBox1);
        Boolean vanilla = vanillaCheckBox.isChecked();

        CheckBox mochaCheckBox = (CheckBox) findViewById(R.id.checkBox2);
        Boolean mocha = mochaCheckBox.isChecked();

        CheckBox caramelCheckBox = (CheckBox) findViewById(R.id.checkBox3);
        Boolean caramel = caramelCheckBox.isChecked();

        CheckBox strawberryCheckBox = (CheckBox) findViewById(R.id.checkBox4);
        Boolean strawberry = strawberryCheckBox.isChecked();

        CheckBox peachCheckBox = (CheckBox) findViewById(R.id.checkBox5);
        Boolean peach = peachCheckBox.isChecked();

        CheckBox citrusCheckBox = (CheckBox) findViewById(R.id.checkBox6);
        Boolean citrus = citrusCheckBox.isChecked();

        //pick drink
        String type;
        String flavor;
        String yourDrink = "";

        //check radio buttons
        if (season_id == -1) {
            //toast
            Context context = getApplicationContext();
            CharSequence text = "Please select a season";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        } else {
            if (temperature) { //hot drink
                if (beverageType.equals("coffee")) {
                    if(vanilla){
                        yourDrink = " coffee with vanilla sweetener";
                    }else if(mocha){
                        yourDrink = " coffee with mocha sweetener";
                    }else if(caramel){
                        yourDrink = " coffee with caramel sweetener";
                    }else {
                        yourDrink = " regular coffee";
                    }
                } else if (beverageType.equals("latte")) {
                    if(vanilla){
                        yourDrink = " Vanilla Latte";
                    }else if(mocha){
                        yourDrink = " Mocha Latte";
                    }else if(caramel){
                        yourDrink = " Caramel Latte";
                    }else{
                        yourDrink = " Latte";
                    }
                } else if (beverageType.equals("tea")) {
                    if(strawberry){
                        yourDrink = " Passion Tango Herbal Tea";
                    }else if(peach){
                        yourDrink = " Peach Tranquility Herbal Tea";
                    }else if(citrus){
                        yourDrink = " Honey Citrus Mint Tea";
                    }else{
                        yourDrink = " Organic Herbal Tea";
                    }
                }
            } else { //over ice
                if (beverageType.equals("coffee")) {
                    if(vanilla){
                        yourDrink = " Vanilla Iced Coffee";
                    }else if(mocha){
                        yourDrink = " Mocha Iced Coffee";
                    }else if(caramel){
                        yourDrink = " Caramel Iced Coffee";
                    }else {
                        yourDrink = " regular Iced Coffee";
                    }
                } else if (beverageType.equals("latte")) {
                    if(vanilla){
                        yourDrink = " Iced Vanilla Latte";
                    }else if(mocha){
                        yourDrink = " Iced Mocha Latte";
                    }else if(caramel){
                        yourDrink = " Iced Caramel Latte";
                    }else{
                        yourDrink = " Iced Latte";
                    }
                } else if (beverageType.equals("tea")) {
                    if(strawberry){
                        yourDrink = " Iced Strawberry Green Tea Infusion";
                    }else if(peach){
                        yourDrink = " Teavana Iced Peach Green Tea";
                    }else if(citrus){
                        yourDrink = " Iced Peach Citrus White Tea Infusion";
                    }else{
                        yourDrink = " Iced Sweet Tea";
                    }
                }
            }
        }

        if(answer){
            if(season_id == R.id.radioButton1){
                yourDrink = " Mango Pineapple Frappuccino Blended Creme";
            }
            else if(season_id == R.id.radioButton2){
                yourDrink = " Pumpkin Spice Latte";
            }
            else if(season_id == R.id.radioButton3){
                yourDrink = " Caramel Brulee Latee";
            }
        }
            //Text View
            TextView drinkSelection = (TextView) findViewById(R.id.drinkTextView);
            drinkSelection.setText("Hi " + nameValue + "! Your Starbucks drink is a" + yourDrink + ".");
        }
}

