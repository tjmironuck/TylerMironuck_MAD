package com.example.tjmir.denvertainment2;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class ReceiveEntertainmentActivity extends AppCompatActivity {
    private String entertainment;
    private String entertainmentURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_entertainment);

        //get intent = getIntent();
        entertainment = getIntent().getStringExtra("entertainmentName");
        entertainmentURL = getIntent().getStringExtra("entertainmentURL");
        Log.i("entertainment received", entertainment);
        Log.i("url received", entertainmentURL);

        //update text view
        TextView messageView = (TextView)findViewById(R.id.textView3);
        messageView.setText("You should check out "+entertainment);

        //get image button
        final ImageButton imageButton = (ImageButton)findViewById(R.id.imageButton4);

        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadWebSite(view);
            }
        };

        //add listener to the button
        imageButton.setOnClickListener(onclick);

        ImageView entertainmentImage = (ImageView)findViewById(R.id.imageView2);
        if(entertainment.equals("a Red Rocks concert!")) {
            entertainmentImage.setImageResource(R.drawable.redrocks);
        }else if(entertainment.equals("a Colorado Rockies game!")) {
            entertainmentImage.setImageResource(R.drawable.coorsfieldevening);
        }else if(entertainment.equals("Zoo Lights!")) {
            entertainmentImage.setImageResource(R.drawable.zoolights);
        }else if(entertainment.equals("Denver Museum of Science and Nature")) {
            entertainmentImage.setImageResource(R.drawable.museum);
        }
        else if(entertainment.equals("Denver Performing Arts Complex")) {
            entertainmentImage.setImageResource(R.drawable.performingartscomplex);
        }
    }

    public void loadWebSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(entertainmentURL));
        startActivity(intent);
    }
}
