package com.example.tjmir.finalapp;

/**
 * Created by tjmir on 12/17/2017.
 */

public class TacoShop {
    private String tacoShop;
    private String tacoShopURL;

    private void setTacoInfo(Integer coffeeCrowd) {
        switch (coffeeCrowd){
            case 0: //illegal petes
                tacoShop="Illegal Petes";
                tacoShopURL="http://illegalpetes.com";
                break;
            case 1: //chipotle
                tacoShop="Chipotle";
                tacoShopURL="https://www.chipotle.com/";
                break;
            case 2: //bartaco
                tacoShop="Bartaco";
                tacoShopURL="https://bartaco.com";
                break;
            default:
                tacoShop="none";
                tacoShopURL="https://www.google.com/";
        }
    }

    public void setTacoShop(Integer coffeeCrowd){
        setTacoInfo(coffeeCrowd);
    }

    public void setTacoShopURL(Integer coffeeCrowd){
        setTacoInfo(coffeeCrowd);
    }

    public String getTacoShop(){
        return tacoShop;
    }

    public String getTacoShopURL(){
        return tacoShopURL;
    }
}
