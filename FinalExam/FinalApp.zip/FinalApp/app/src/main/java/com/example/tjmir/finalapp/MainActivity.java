package com.example.tjmir.finalapp;

import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    private TacoShop myTacoShop = new TacoShop();

    String burritoOrTaco = "";
    String meatOrVeggie = "";
    String salsaChoice = "";
    String sourCreamChoice = "";
    String cheeseChoice = "";
    String guacamoleChoice = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //get button
        final Button button = (Button) findViewById(R.id.button);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener() {
            public void onClick(View view) {
                findBurrito(view);
            }
        };
        //add listener to the button
        button.setOnClickListener(onclick);
    }

    public void buildBurrito(View view) {
        //toggle button
        ToggleButton toggle = (ToggleButton)findViewById(R.id.toggleButton);
        boolean type = toggle.isChecked(); //toggleTag is either true or false

        //spinner
        Spinner spinnerWidget = (Spinner)findViewById(R.id.spinner);
        String spinnerCategory = String.valueOf(spinnerWidget.getSelectedItem());


        //Radiobuttons
        RadioGroup choice = (RadioGroup)findViewById(R.id.radioGroup);
        int choice_id = choice.getCheckedRadioButtonId();

        //checkboxes
        CheckBox salsaCheckBox = (CheckBox)findViewById(R.id.checkBox1);
        Boolean salsa = salsaCheckBox.isChecked();

        CheckBox sourCreamCheckBox = (CheckBox)findViewById(R.id.checkBox2);
        Boolean sourCream = sourCreamCheckBox.isChecked();

        CheckBox cheeseCheckBox = (CheckBox)findViewById(R.id.checkBox3);
        Boolean cheese = cheeseCheckBox.isChecked();

        CheckBox guacamoleCheckBox = (CheckBox)findViewById(R.id.checkBox4);
        Boolean guacamole = guacamoleCheckBox.isChecked();

        //get burrito name from textEdit widget
        EditText name = (EditText)findViewById(R.id.editText);
        String burritoName = name.getText().toString();


        //save meat or veggie selection
        if(type){//if veggie is true
            meatOrVeggie = "veggie";
        }else{
            meatOrVeggie = "meat";
        }

        if(choice_id == R.id.radioButton) {
            burritoOrTaco = "burrito";
            //change picture to burrito
            ImageView picture = (ImageView)findViewById(R.id.imageView);
            picture.setImageResource(R.drawable.burrito);

        }else if(choice_id == R.id.radioButton2){
            burritoOrTaco = " Taco";
            //change picture to Taco
            ImageView picture = (ImageView)findViewById(R.id.imageView);
            picture.setImageResource(R.drawable.taco);
        }

        if(salsa){
            salsaChoice = " salsa";
        }else{
            salsaChoice = "";
        }
        if(sourCream){
            sourCreamChoice = " sour cream";
        }else{
            sourCreamChoice = "";
        }
        if(cheese){
            cheeseChoice = " cheese";
        }else{
            cheeseChoice = "";
        }
        if(guacamole){
            guacamoleChoice = " guacamole";
        }else{
            guacamoleChoice = "";
        }

        TextView burritoDescription = (TextView)findViewById(R.id.textView3);
        burritoDescription.setText("The "+burritoName+" is a "+burritoOrTaco+" with "+meatOrVeggie+" with"+salsaChoice+sourCreamChoice+cheeseChoice+guacamoleChoice+" you'd like to eat on "+spinnerCategory);

    }



    public void findBurrito(View view){
        //get spinner
        Spinner spinnerWidget = (Spinner)findViewById(R.id.spinner);
        String spinnerCategory = String.valueOf(spinnerWidget.getSelectedItem());
        //get spinner item array position
        Integer locationTag = spinnerWidget.getSelectedItemPosition();

        //set the taco shop
        myTacoShop.setTacoShop(locationTag);
        //get suggested taco shop
        String suggestedTacoShop = myTacoShop.getTacoShop();
        //get URL of suggested Taco shop
        String suggestedTacoShopURL = myTacoShop.getTacoShopURL();

        //create an intent
        Intent intent = new Intent(this, ReceiveInfoActivity.class);

        //pass data
        intent.putExtra("tacoShopName", suggestedTacoShop);
        intent.putExtra("tacoShopURL", suggestedTacoShopURL);

        //start the intent
        startActivity(intent);
    }


}
