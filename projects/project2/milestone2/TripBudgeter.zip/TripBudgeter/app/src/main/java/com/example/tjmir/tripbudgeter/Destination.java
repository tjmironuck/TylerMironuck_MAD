package com.example.tjmir.tripbudgeter;

/**
 * Created by tjmir on 11/29/2017.
 */

public class Destination {
    private String destinationCity;
    private String destinationHotelURL;


    private void setDestinationInfo(Integer budget){
        switch(budget) {
            case 500: //Chicago
                destinationCity = "Chicago, Illinois";
                destinationHotelURL = "http://www.wyndhamgrandchicagoriverfront.com";
                break;
            case 1000: //Los Angeles
                destinationCity = "Los Angeles, California";
                destinationHotelURL = "https://www3.hilton.com/en/hotels/california/hilton-los-angeles-airport-LAXAHHH/index.html";
                break;
            case 1500: //New York
                destinationCity = "New York City, New York";
                destinationHotelURL = "http://www.hotelstanford.com/default-en.html";
                break;
            case 2000: //Paris
                destinationCity = "Paris, France";
                destinationHotelURL = "https://hotel-paris-bosquet.com/en/";
                break;
            default:
                destinationCity = "none";
                destinationHotelURL = "https://www.google.com/";
        }
    }

    public void setDestinationCity(Integer budget){
        setDestinationInfo(budget);
    }

    public void setDestinationHotelURL(Integer budget){
        setDestinationInfo(budget);
    }

    public String getDestinationCity(){
        return destinationCity;
    }

    public String getDestinationHotelURL(){
        return destinationHotelURL;
    }
}