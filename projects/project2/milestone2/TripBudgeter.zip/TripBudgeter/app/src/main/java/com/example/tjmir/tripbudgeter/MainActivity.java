package com.example.tjmir.tripbudgeter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private static SeekBar seek_bar;
    private static TextView text_view;
    int step = 500;
    int max = 2000;
    int min = 500;
    int budget = 0;

    private Destination myDestination = new Destination();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        formatSeekBar();

        //get button
        final Button button = (Button)findViewById(R.id.button);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                findTrip(view);
            }
        };
        //add listener to the button
        button.setOnClickListener(onclick);
    }

    public void formatSeekBar(){

        seek_bar = (SeekBar)findViewById(R.id.seekBar);
        text_view = (TextView)findViewById(R.id.textView5);
        int temp = min + ( (seek_bar.getProgress()) * step);
        text_view.setText("$"+temp);
        seek_bar.setMax( (max - min)/step);

        seek_bar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    int value;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        value = min + (progress * step);
                        text_view.setText("$"+value);
                        budget = value;
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        text_view.setText("$"+value);
                    }
                }
        );
    }

    public void findTrip(View view){
        //get destination identifier
        //set destination
        myDestination.setDestinationCity(budget);
        //get suggested destination
        String suggestedDestination = myDestination.getDestinationCity();
        //get URL of suggested destination hotel
        String hotelURL = myDestination.getDestinationHotelURL();
        Log.i("city", suggestedDestination);
        Log.i("url", hotelURL);

        //create an intent
        Intent intent = new Intent(this, destinationActivity.class);

        //pass data
        intent.putExtra("destinationCity", suggestedDestination);
        intent.putExtra("hotelURL", hotelURL);

        //start the intent
        startActivity(intent);

    }


}
