package com.example.tjmir.tripbudgeter;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class destinationActivity extends AppCompatActivity {

    private String destinationCity;
    private String destinationHotelURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_destination);

        //get intent
        Intent intent = getIntent();
        destinationCity = intent.getStringExtra("destinationCity");
        destinationHotelURL = intent.getStringExtra("hotelURL");
        Log.i("destination received", destinationCity);
        Log.i("url received", destinationHotelURL);

        //update city label
        TextView messageView = (TextView)findViewById(R.id.cityTextView);
        messageView.setText(destinationCity);

        //update hotel label
        TextView hotelName = (TextView)findViewById(R.id.hotelTextView);
        hotelName.setText(destinationHotelURL);

        //get image button
        final ImageButton imageButton = (ImageButton)findViewById(R.id.imageButton3);

        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadWebSite(view);
            }
        };

        //add listener to the button
        imageButton.setOnClickListener(onclick);

        ImageView entertainmentImage = (ImageView)findViewById(R.id.imageView3);
        if(destinationCity.equals("Paris, France")) {
            entertainmentImage.setImageResource(R.drawable.eiffeltower);
        }else if(destinationCity.equals("New York City, New York")) {
            entertainmentImage.setImageResource(R.drawable.newyork);
        }else if(destinationCity.equals("Los Angeles, California")) {
            entertainmentImage.setImageResource(R.drawable.losangeles);
        }else if(destinationCity.equals("Chicago, Illinois")) {
            entertainmentImage.setImageResource(R.drawable.chicago);
        }
    }

    public void loadWebSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(destinationHotelURL));
        startActivity(intent);
    }
}
