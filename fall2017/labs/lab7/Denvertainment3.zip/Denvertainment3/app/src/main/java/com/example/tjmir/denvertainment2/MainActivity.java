package com.example.tjmir.denvertainment2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    private Entertainment myEntertainment = new Entertainment();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //get button
        final Button button = (Button) findViewById(R.id.button);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                findEntertanment(view);
            }
        };
        button.setOnClickListener(onclick);
    }

    public void findEntertanment(View view){
        //get spinner
        Spinner categorySpinner = (Spinner)findViewById(R.id.spinner);
        //get spinner item array position
        Integer category = categorySpinner.getSelectedItemPosition();
        //set the entertainmnent
        myEntertainment.setEntertainment(category);
        //get suggested entertainment event
        String suggestedEntertainment = myEntertainment.getEntertainment();
        //get URL of suggested entertainment event
        String suggestedEntertainmentURL = myEntertainment.getEntertainmentURL();
        Log.i("shop", suggestedEntertainment);
        Log.i("url", suggestedEntertainmentURL);

        //create an intent
        Intent intent = new Intent(this, ReceiveEntertainmentActivity.class);

        //pass data
        intent.putExtra("entertainmentName", suggestedEntertainment);
        intent.putExtra("entertainmentURL", suggestedEntertainmentURL);

        //start the intent
        startActivity(intent);
    }
}
