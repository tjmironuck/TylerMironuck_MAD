package com.example.tjmir.denvertainment2;

/**
 * Created by tjmir on 12/4/2017.
 */

public class Entertainment {
    private String entertainment;
    private String entertainmentURL;

    private void setEntertainmentInfo(Integer entertainmentCategory){
        switch(entertainmentCategory){
            case 0: //music
                entertainment="a Red Rocks concert!";
                entertainmentURL="http://www.redrocksonline.com/concerts-events/listing";
                break;
            case 1: //sports
                entertainment="a Colorado Rockies game!";
                entertainmentURL="https://www.mlb.com/rockies/tickets";
                break;
            case 2: //festivals
                entertainment="Zoo Lights!";
                entertainmentURL="https://tickets.denverzoo.org/default.aspx";
                break;
            case 3: //science and nature
                entertainment="Denver Museum of Science and Nature";
                entertainmentURL="https://www.dmns.org/plan-your-visit/hours-and-ticket-prices/";
                break;
            case 4: //theater
                entertainment="Denver Performing Arts Complex";
                entertainmentURL="https://www.denvercenter.org/shows";
                break;
            default:
                entertainment="none";
                entertainmentURL="https://www.google.com";
        }
    }

    public void setEntertainment(Integer entertainmentCategory){
        setEntertainmentInfo(entertainmentCategory);
    }

    public void setEntertainmentURL(Integer entertainmentCategory){
        setEntertainmentInfo(entertainmentCategory);
    }

    public String getEntertainment(){
        return entertainment;
    }

    public String getEntertainmentURL(){
        return entertainmentURL;
    }
}
