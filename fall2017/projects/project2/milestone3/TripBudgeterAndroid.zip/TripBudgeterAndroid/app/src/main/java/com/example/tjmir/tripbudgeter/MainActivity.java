package com.example.tjmir.tripbudgeter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private static SeekBar seek_bar;
    private static TextView text_view;
    int step = 500;
    int max = 2000;
    int min = 500;
    int budget = 500;
    int destinationTag = 0;
    double numOfPeople = 0;
    double numOfNights = 0;
    double flightExpense = 0;
    double hotelExpense = 0;
    double totalExpense = 0;
    double spendingMoney = 0;


    private Destination myDestination = new Destination();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        formatSeekBar();

        //get button
        final Button button = (Button)findViewById(R.id.button);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                findTrip(view);
            }
        };
        //add listener to the button
        button.setOnClickListener(onclick);
    }

    public void formatSeekBar(){

        seek_bar = (SeekBar)findViewById(R.id.seekBar);
        text_view = (TextView)findViewById(R.id.textView5);
        int temp = min + ( (seek_bar.getProgress()) * step);
        text_view.setText("$"+temp);
        seek_bar.setMax( (max - min)/step);

        seek_bar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    int value;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        value = min + (progress * step);
                        text_view.setText("$"+value);
                        budget = value;
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        text_view.setText("$"+value);
                    }
                }
        );
    }

    public void findTrip(View view){
        //RadioButtons
        RadioGroup region = (RadioGroup) findViewById(R.id.radioGroup3);
        int region_id = region.getCheckedRadioButtonId();

        //Spinner for number of people traveling
        Spinner people = (Spinner) findViewById(R.id.spinner1);
        String numPeople = String.valueOf(people.getSelectedItem());

        //Spinner for number of nights
        Spinner nights = (Spinner) findViewById(R.id.spinner2);
        String numNights = String.valueOf(nights.getSelectedItem());

        if(region_id == R.id.radioButton2 && budget < 2000){
            //toast
            Context context = getApplicationContext();
            CharSequence text = "Please increase your budget if you would like to travel abroad.";
            int duration = Toast.LENGTH_LONG;

            Toast toast = Toast.makeText(context,text,duration);
            toast.show();
        }/*****************************THIS SECTION HANDLES THE CASE FOR PARIS*******************************/
        else {//all other scenarios
            //if user selects abroad..
            if(region_id == R.id.radioButton2){
                switch (numPeople) {
                    case "1":
                        numOfPeople = 1;
                        destinationTag = 1;
                        break;
                    case "2":
                        numOfPeople = 2;
                        destinationTag = 1;
                        break;
                    case "3":
                        //toast
                        Context context = getApplicationContext();
                        CharSequence text = "Paris is expensive. Please select 2 people or less.";
                        int duration = Toast.LENGTH_SHORT;

                        Toast toast = Toast.makeText(context,text,duration);
                        toast.show();
                        destinationTag = 0;
                        break;
                    default:
                        destinationTag = 0;
                }

                switch (numNights) {
                    case "1":
                        numOfNights = 1;
                        break;
                    case "2":
                        numOfNights = 2;
                        break;
                    case "3":
                        numOfNights = 3;
                        break;
                }

                //Calculating cost to fly
                //For paris, cheapest flights are $500 per person. So multiply $500 by number of people
                flightExpense = 500*numOfPeople;

                //Calculating cost of hotel for requested number of nights
                hotelExpense = 138 * numOfNights;

                //Calculating total expenses of flight and hotel
                totalExpense = flightExpense + hotelExpense;
            } /*************************THIS SECTION HANDLES THE CASE FOR U.S. DESTINATIONS**************************/
            else if(region_id == R.id.radioButton1){
                //Find how many people are traveling
                switch (numPeople) {
                    case "1":
                        numOfPeople = 1;
                        break;
                    case "2":
                        numOfPeople = 2;
                        break;
                    case "3":
                        numOfPeople = 3;
                        break;
                }
                //Find how many nights they are staying
                switch (numNights) {
                    case "1":
                        numOfNights = 1;
                        break;
                    case "2":
                        numOfNights = 2;
                        break;
                    case "3":
                        numOfNights = 3;
                        break;
                }
                if(budget == 2000 || budget == 1500){
                    destinationTag = 2;
                    //Calculating cost of hotel for requested number of nights
                    if(numOfPeople > 2){
                        hotelExpense = 207 * numOfNights;
                    }else {
                        hotelExpense = 130 * numOfNights;
                    }
                }else if(budget == 1000){
                    //Calculating cost of hotel for requested number of nights
                    if(numOfPeople > 2){
                        //toast
                        Context context = getApplicationContext();
                        CharSequence text = "Flights are expensive. Please select 2 people or less.";
                        int duration = Toast.LENGTH_SHORT;

                        Toast toast = Toast.makeText(context,text,duration);
                        toast.show();
                        destinationTag = 0;
                    }else {
                        hotelExpense = 111 * numOfNights;
                        destinationTag = 3;
                    }
                }else if(budget == 500){
                    //Calculating cost of hotel for requested number of nights
                    if(numOfPeople > 1){
                        //toast
                        Context context = getApplicationContext();
                        CharSequence text = "With a budget of $500, you can only afford to vacation by yourself.";
                        int duration = Toast.LENGTH_LONG;

                        Toast toast = Toast.makeText(context,text,duration);
                        toast.show();
                        destinationTag = 0;
                    }else if (numOfNights > 2){
                        //toast
                        Context context = getApplicationContext();
                        CharSequence text = "With a budget of $500, you can only afford 2 nights.";
                        int duration = Toast.LENGTH_SHORT;

                        Toast toast = Toast.makeText(context,text,duration);
                        toast.show();
                        destinationTag = 0;
                    }else{
                        hotelExpense = 103 * numOfNights;
                        destinationTag = 4;
                    }
                }

                //For flights in the US, the lowest flighs are on average $275
                flightExpense = 275 * numOfPeople;

                //Calculating total expenses of flight and hotel
                totalExpense = flightExpense + hotelExpense;
            }

            //Calculate total cash left for entertainment
            spendingMoney = budget - totalExpense;

            //get destination identifier
            //set destination
            myDestination.setDestinationCity(destinationTag);
            //get suggested destination
            String suggestedDestination = myDestination.getDestinationCity();
            //get URL of suggested destination hotel
            String hotelURL = myDestination.getDestinationHotelURL();
            Log.i("city", suggestedDestination);
            Log.i("url", hotelURL);

            //create an intent
            Intent intent = new Intent(this, destinationActivity.class);

            //pass data
            intent.putExtra("destinationCity", suggestedDestination);
            intent.putExtra("hotelURL", hotelURL);
            intent.putExtra("spendingCash", spendingMoney);

            //start the intent

            if(region_id != -1){
                if(destinationTag != 0){
                    startActivity(intent);
                }
            }
            else{
                //toast
                Context context = getApplicationContext();
                CharSequence text = "Please select US or Abroad.";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context,text,duration);
                toast.show();
            }

        }

    }


}
