package com.example.tjmir.tripbudgeter;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class destinationActivity extends AppCompatActivity {

    private String destinationCity;
    private String destinationHotelURL;
    private Double cashForEntertainment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_destination);

        //get intent
        Intent intent = getIntent();
        destinationCity = intent.getStringExtra("destinationCity");
        destinationHotelURL = intent.getStringExtra("hotelURL");
        cashForEntertainment = intent.getDoubleExtra("spendingCash", 0);
        Log.i("destination received", destinationCity);
        Log.i("url received", destinationHotelURL);

        //update city label
        TextView messageView = (TextView)findViewById(R.id.cityTextView);
        messageView.setText(destinationCity);

        //get website image button
        final ImageButton imageButton = (ImageButton)findViewById(R.id.imageButton3);

        //create listener for website button
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadWebSite(view);
            }
        };

        //add listener to the button
        imageButton.setOnClickListener(onclick);


        //get directions image button
        final ImageButton imageButton2 = (ImageButton)findViewById(R.id.imageButton);

        //create listner for directions button

        View.OnClickListener onclick2 = new View.OnClickListener(){
            public void onClick(View view){
                openDirections(view);
            }
        };

        //add listener to website button
        imageButton2.setOnClickListener(onclick2);

        ImageView entertainmentImage = (ImageView)findViewById(R.id.imageView3);

        if(destinationCity.equals("Paris, France")) {
            entertainmentImage.setImageResource(R.drawable.eiffeltower);
            //update hotel label
            TextView hotelName = (TextView)findViewById(R.id.hotelTextView);
            hotelName.setText("Hotel Relais Bosquet");

            //update entertainment info
            TextView entertianment = (TextView)findViewById(R.id.entertainmentTextView);
            entertianment.setText("You have $"+cashForEntertainment+" to spend on entertainment while you are there. May I suggest visiting the Eiffel Tower?");

        }else if(destinationCity.equals("New York City, New York")) {
            entertainmentImage.setImageResource(R.drawable.newyork);
            //update hotel label
            TextView hotelName = (TextView)findViewById(R.id.hotelTextView);
            hotelName.setText("Hotel Stanford");

            //update entertainment info
            TextView entertianment = (TextView)findViewById(R.id.entertainmentTextView);
            entertianment.setText("You have $"+cashForEntertainment+" to spend on entertainment while you are there. May I suggest visiting the Empire State Building?");

        }else if(destinationCity.equals("Los Angeles, California")) {
            entertainmentImage.setImageResource(R.drawable.losangeles);
            //update hotel label
            TextView hotelName = (TextView)findViewById(R.id.hotelTextView);
            hotelName.setText("Hilton Los Angeles Airport");

            //update entertainment info
            TextView entertianment = (TextView)findViewById(R.id.entertainmentTextView);
            entertianment.setText("You have $"+cashForEntertainment+" to spend on entertainment while you are there. May I suggest visiting the Hollywood Sign?");
        }else if(destinationCity.equals("Chicago, Illinois")) {
            entertainmentImage.setImageResource(R.drawable.chicago);
            //update hotel label
            TextView hotelName = (TextView)findViewById(R.id.hotelTextView);
            hotelName.setText("Wyndham Grand Chicago Riverfront");

            //update entertainment info
            TextView entertianment = (TextView)findViewById(R.id.entertainmentTextView);
            entertianment.setText("You have $"+cashForEntertainment+" to spend on entertainment while you are there. May I suggest visiting the Millennium Park?");
        }

    }

    public void loadWebSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(destinationHotelURL));
        startActivity(intent);
    }

    public void openDirections(View view){
        //create an intent
        Intent intent = new Intent(this, MapsActivity.class);

        //pass data
        intent.putExtra("destinationCity", destinationCity);

        //start the intent
        startActivity(intent);
    }

}
